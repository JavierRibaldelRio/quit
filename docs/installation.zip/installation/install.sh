g++ -o stop main.cpp

chmod +x stop

mv stop /usr/bin/
