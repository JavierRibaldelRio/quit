#Install stop
#First you have to make the file executable

chmod +x install.sh

#An then execute

sudo ./install.sh